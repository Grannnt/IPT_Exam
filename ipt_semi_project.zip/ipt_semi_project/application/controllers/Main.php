<!-- Controllers -->

<?php  
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * summary
 */
class Main extends CI_Controller
{

	function __construct()
	{
      //db_data came from models
      // d is a assign variable 
		parent:: __construct();
		$this->load->model('db_data','d');
	}


   function index(){


   	$data['datas'] = $this->d->getdata();
      // admin($data);
   	// print_r($data);
   	// echo 'Hi';
      //getdata() from model file
   	// $this->load->view = this function is a default function in CI. view means go to the view folder
   	// insde the parameter ('sample/index')
   	// sample is a folder u created inside the views folder 
   	// index is file that u created inside the sample folder
   	// the index datas is a variable from views inside the sample folder

   	//then call $data to pass again on to index.php
      // $this->load->view('layout/header');
   	$this->load->view('sample/index',$data);
      // $this->load->view('layout/footer');
   }
   // function sign
   // sign is use to call inside the base_url
   public function sign()
   {
      $result = $this->d->signup();
      redirect(base_url('main/index'));
   }

   public function login()
   {
      $log = $this->d->user_login();
      redirect(base_url('admin/data'));
   }

   public function edit($id){
      $data['tbl_data'] = $this->d->getid($id);
      $this->load->view('sample/edit',$data);
     
   }

   public function update()
   {
      $result = $this->d->update();
      redirect(base_url('main/index'));
   }

   public function delete($id)
   {
      $result = $this->d->delete_data($id);
      redirect(base_url('main/index'));
   }

}


?>