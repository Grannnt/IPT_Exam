<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Crud</title>
	<link rel="stylesheet" href="<?php echo base_url('assets/css/dashboard.css'); ?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.css'); ?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/modal.css'); ?>">
	<script src="<?php echo base_url('assets/js/fontawesome.js') ?>" type="text/javascript"></script>
	<script src="<?php echo base_url('assets/js/jquery.js') ?>" type="text/javascript"></script>
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Lato:wght@700&family=Roboto&display=swap" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-light bg-light">
  <div class="container-fluid">
    <a class="text-muted nav-link fs-4" href="<?php echo base_url('sample/index')?>">CRUD</a>
    <div class="d-flex">
			<div class="col-md-12">
				<a id="signup" title="Add Data" class="btn btn-primary">Add Data</a>
			</div>
		</div>
  </div>
</nav>


<div class="container">
	<h3 class="text-dark text-center">Data</h3>
</div>

<!-- data -->
<section class="intro">
  <div class="bg-image h-100" style="background-color: #f5f7fa;">
    <div class="mask d-flex align-items-center h-100">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-12">
            <div class="card">
              <div class="card-body p-0">
                <div class="table-responsive" style="position: relative; height: 700px">
                  <table class="table mb-0">
                    <thead class="bg-dark">
                      <tr align="center">
                        <th scope="col" class="text-light">#</th>
                        <th scope="col" class="text-light">Full Name</th>
                        <th scope="col" class="text-light">Sentence</th>
                       
                        <th scope="col" class="text-light">Edit</th>
                        <th scope="col" class="text-light">Delete</th>
                      </tr>
                    </thead>
                    <tbody>
                     <?php 
						if ($datas) {
							foreach ($datas as $data) {
							    ?>
							    <tr align="center">
							    <td class="text-dark"><?php echo $data->id; ?></td>
							    	<td class="text-dark"><?php echo $data->fname." ".$data->lname; ?></td>
							    	<td class="text-dark"><?php echo $data->email; ?></td>
							    	<td><a class="nav-link btn btn-primary text-light" href="<?php echo base_url('main/edit/' .$data->id); ?>" id="edit">Edit</a></td>
							    	<td><a class="nav-link btn btn-danger text-light" href="<?php echo base_url('main/delete/' .$data->id); ?>" id="delete" >Delete</a></td>
							    </tr>
							    <?php
							}
						}
					?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- end of data -->

<!-- signup -->
	<div class="sign">
		<div class="container w-50">
            <div class="modal-content bg-secondary">
                <div class="modal-header">
                    <div class="col-md-12">
                        <h3 class="text-left modal-title fw-bold">Add Data</h3>
                    </div>
                </div>
                <div class="modal-body">
                    <form action="<?php echo base_url('main/sign') ?>" method="POST" autocomplete="off" class="form-group">
                        
                        <div class="mb-3 form-floating">
                            <input type="text" name="fname" required placeholder="First Name" id="floatingInput" class="form-control">
                             <label for="floatingInput">
                                First Name:
                            </label>
                        </div>
                         <div class="mb-3 form-floating">
                            
                            <input type="text" name="lname" required placeholder="Last Name" id="floatingInput" class="form-control">
                            <label for="floatingInput">
                                Last Name:
                            </label>
                        </div>
                         <div class="mb-3 form-floating">
                          	
                          	<!-- <textarea id="" cols="4" rows="4" class="form-control" id="floatingInput" name="email"></textarea> -->
                            <input type="text"  name="email" required placeholder="Email" id="floatingInput" class="form-control">
                            <label for="floatingInput">
                               Sentence
                            </label>
                        </div>
                        <div class="mb-3 form-floating">
                            
                            <input type="password" name="password" required placeholder="Password" class="form-control">
                            <label for="floatingInput">
                                Password
                            </label>
                        </div>
                        <br>
                        <div class="col-md-12" class="form-label">
                            <button type="submit" name="register" class="btn btn-primary">Register</button>
                        </div>
                    </form>
                     <span id="close"><i class="fas fa-times"></i></span>
                </div>
            </div>
        </div>
	</div>
<!-- end of signup -->


	

<script src="<?php echo base_url('assets/js/function.js') ?>" type="text/javascript"></script>

	
<script type="text/javascript">
	$(document).ready(function() {
		$(document).on('click', '#close', function(event) {
			event.preventDefault();
			$('.sign').removeClass('bg-active');
			/* Act on the event */
		});
		$(document).on('click', '#signup', function(event) {
			event.preventDefault();
			$('.sign').addClass('bg-active');
			/* Act on the event */
		});	
	});
</script>

<script type="text/javascript">

	var sign = document.querySelector(".sign");
	var fname = document.getElementById('fname');
	var lname = document.getElementById('lname');
	var user = document.getElementById('user');
	var pass = document.getElementById('pass');
	var log = document.querySelector(".login");


	//handler
	document.addEventListener('keyup',signup_exit,false);
	document.addEventListener('keyup',log_exit,false);


	function signup_exit(btn) {
		if (btn.charCode == 27 || btn.keyCode == 27) {
			sign.classList.remove('bg-active');
			fname.value="";
			lname.value="";
			user.value="";
			pass.value="";
		}
	}

	function log_exit(btn){
		if (btn.charCode == 27 || btn.keyCode == 27) {
			log.classList.remove('bg-active');
			user.value="";
			pass.value="";
		}
	}

</script>

</body>
</html>


